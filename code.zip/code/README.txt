drug stur cluster.ipynb is doing baisc clustering using drug information.
linearSVR and method_2 are designed for the SVR prediction.
nlp.py is the function for the basic nlp for "SMILE" variable and is used in NLP.ipynb
Tensor_first.ipynb used the Tensor method combined with nlp features.
cpa_1.ipynb using cpa package but still need to do some debuging.

data dir contains all the dataset from the challenge (8 files, 5csv and 3 parquet)