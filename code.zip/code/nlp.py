
import numpy as np
import pandas as pd
import itertools

def generate_nlp(s):
    chars = [char for char in s]
    
    # 基本统计
    total_chars = len(chars)
    count_C = chars.count('C')
    count_c = chars.count('c')
    count_N = chars.count('N')
    count_n = chars.count('n')
    count_O = chars.count('O')
    count_H = chars.count('H')
    count_F = chars.count('F')
    
    count_1 = chars.count('1')
    count_2 = chars.count('2')
    
    count_a = chars.count('@')
    count_open_bracket = chars.count('(')
    count_close_bracket = chars.count(')')
    
    count_open_s_bracket = chars.count('[')
    count_close_s_bracket = chars.count(']')
    
    count_equal = chars.count('=')

    
    # 结构特征
    in_bracket = ''.join(chars).split('(')[1].split(')')[0] if '(' in chars and ')' in chars else ''
    chars_in_bracket = len(in_bracket)
    max_consecutive_C = max(len(list(g)) for k, g in itertools.groupby(chars) if k == 'C')
    
    # Calculating num_rings and num_substructures
    num_rings = (count_open_bracket + count_close_bracket) // 2
    num_substructures = count_a
    
    # Creating a pandas Series with all counts and structural features
    data = {
        'total_chars': total_chars,
        'count_C': count_C,
        'count_c': count_c,
        'count_N': count_N,
        'count_n': count_n,
        'count_O': count_O,
        'count_H': count_H,
        'count_F': count_F,
        'count_1': count_1,
        'count_2': count_2,
        'count_a': count_a,
        'count_open_bracket': count_open_bracket,
        'count_close_bracket': count_close_bracket,
        'count_open_s_bracket': count_open_s_bracket,
        'count_close_s_bracket': count_close_s_bracket,
        'count_equal': count_equal,
        'chars_in_bracket': chars_in_bracket,
        'max_consecutive_C': max_consecutive_C,
        'num_rings': num_rings,
        'num_substructures': num_substructures
    }
    
    return pd.Series(data)
